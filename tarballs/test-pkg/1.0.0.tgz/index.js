module.exports = 'hello from test-pkg';
